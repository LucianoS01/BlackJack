import Controlador.Controlador;
import Controlador.IControlador;
import Modelo.BackJack;
import Modelo.IJuego;
import Vista.IVista;
import Vista.VistaConsola;
import Vista.VistaGraficaa;
import p.Lobby;

import javax.swing.*;

public class Main {


    public static void main(String[] args) {

        /*
        IJuego juego1 = new BackJack();
        IVista vista1 = new VistaGraficaa();
        IControlador controlador1 = new Controlador(vista1);
        vista1.Iniciar();





        //LLammos a la vista Grafica.
        IVista lobby = new Lobby();
        IControlador controlador2 = new Controlador(lobby);
        lobby.Iniciar();




         */

             /*
        java.awt.EventQueue.invokeLater(() -> {
            new Lobby(controlador1).setVisible(true);
        });



         */
    }


}