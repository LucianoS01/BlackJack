package Modelo;

public interface IObserver {

    public void actualizar(IObservable o, Object arg);
}
