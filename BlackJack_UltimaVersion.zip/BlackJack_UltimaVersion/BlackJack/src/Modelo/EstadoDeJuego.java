package Modelo;

public enum EstadoDeJuego {
     GANADOR, EMPATE, PERDEDOR, NINGUNA, FinDeJuego, BLACKJACK;
}
